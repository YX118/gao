"use strict";

var peq = new Uint32Array(0x10000);
var myers_32 = function myers_32(a, b) {
  var n = a.length;
  var m = b.length;
  var lst = 1 << n - 1;
  var pv = -1;
  var mv = 0;
  var sc = n;
  var i = n;
  while (i--) {
    peq[a.charCodeAt(i)] |= 1 << i;
  }
  for (i = 0; i < m; i++) {
    var eq = peq[b.charCodeAt(i)];
    var xv = eq | mv;
    eq |= (eq & pv) + pv ^ pv;
    mv |= ~(eq | pv);
    pv &= eq;
    if (mv & lst) {
      sc++;
    }
    if (pv & lst) {
      sc--;
    }
    mv = mv << 1 | 1;
    pv = pv << 1 | ~(xv | mv);
    mv &= xv;
  }
  i = n;
  while (i--) {
    peq[a.charCodeAt(i)] = 0;
  }
  return sc;
};
var myers_x = function myers_x(b, a) {
  var n = a.length;
  var m = b.length;
  var mhc = [];
  var phc = [];
  var hsize = Math.ceil(n / 32);
  var vsize = Math.ceil(m / 32);
  for (var i = 0; i < hsize; i++) {
    phc[i] = -1;
    mhc[i] = 0;
  }
  var j = 0;
  for (; j < vsize - 1; j++) {
    var _mv = 0;
    var _pv = -1;
    var _start = j * 32;
    var _vlen = Math.min(32, m) + _start;
    for (var k = _start; k < _vlen; k++) {
      peq[b.charCodeAt(k)] |= 1 << k;
    }
    for (var _i = 0; _i < n; _i++) {
      var eq = peq[a.charCodeAt(_i)];
      var pb = phc[_i / 32 | 0] >>> _i & 1;
      var mb = mhc[_i / 32 | 0] >>> _i & 1;
      var xv = eq | _mv;
      var xh = ((eq | mb) & _pv) + _pv ^ _pv | eq | mb;
      var ph = _mv | ~(xh | _pv);
      var mh = _pv & xh;
      if (ph >>> 31 ^ pb) {
        phc[_i / 32 | 0] ^= 1 << _i;
      }
      if (mh >>> 31 ^ mb) {
        mhc[_i / 32 | 0] ^= 1 << _i;
      }
      ph = ph << 1 | pb;
      mh = mh << 1 | mb;
      _pv = mh | ~(xv | ph);
      _mv = ph & xv;
    }
    for (var _k = _start; _k < _vlen; _k++) {
      peq[b.charCodeAt(_k)] = 0;
    }
  }
  var mv = 0;
  var pv = -1;
  var start = j * 32;
  var vlen = Math.min(32, m - start) + start;
  for (var _k2 = start; _k2 < vlen; _k2++) {
    peq[b.charCodeAt(_k2)] |= 1 << _k2;
  }
  var score = m;
  for (var _i2 = 0; _i2 < n; _i2++) {
    var _eq = peq[a.charCodeAt(_i2)];
    var _pb = phc[_i2 / 32 | 0] >>> _i2 & 1;
    var _mb = mhc[_i2 / 32 | 0] >>> _i2 & 1;
    var _xv = _eq | mv;
    var _xh = ((_eq | _mb) & pv) + pv ^ pv | _eq | _mb;
    var _ph = mv | ~(_xh | pv);
    var _mh = pv & _xh;
    score += _ph >>> m - 1 & 1;
    score -= _mh >>> m - 1 & 1;
    if (_ph >>> 31 ^ _pb) {
      phc[_i2 / 32 | 0] ^= 1 << _i2;
    }
    if (_mh >>> 31 ^ _mb) {
      mhc[_i2 / 32 | 0] ^= 1 << _i2;
    }
    _ph = _ph << 1 | _pb;
    _mh = _mh << 1 | _mb;
    pv = _mh | ~(_xv | _ph);
    mv = _ph & _xv;
  }
  for (var _k3 = start; _k3 < vlen; _k3++) {
    peq[b.charCodeAt(_k3)] = 0;
  }
  return score;
};
var distance = function distance(a, b) {
  if (a.length < b.length) {
    var tmp = b;
    b = a;
    a = tmp;
  }
  if (b.length === 0) {
    return a.length;
  }
  if (a.length <= 32) {
    return myers_32(a, b);
  }
  return myers_x(a, b);
};
var closest = function closest(str, arr) {
  var min_distance = Infinity;
  var min_index = 0;
  for (var i = 0; i < arr.length; i++) {
    var dist = distance(str, arr[i]);
    if (dist < min_distance) {
      min_distance = dist;
      min_index = i;
    }
  }
  return arr[min_index];
};
